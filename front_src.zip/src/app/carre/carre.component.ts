import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { of } from 'rxjs';

@Component({
  selector: 'app-carre',
  templateUrl: './carre.component.html',
  styleUrls: ['./carre.component.css']
})
export class CarreComponent {

  private readonly URL = 'http://blue-green-back.test.bdf-build6.paas.eclair.local/color';
  public color;

  constructor(private http: HttpClient) {

    setInterval(() => {
      this.http.get(this.URL, { responseType: 'text'}).subscribe((value) => { this.color=value },
      (err) => {this.color="Red" });
    }, 3000);

  }

}
